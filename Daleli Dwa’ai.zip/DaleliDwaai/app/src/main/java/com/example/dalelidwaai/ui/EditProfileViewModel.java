package com.example.dalelidwaai.ui;

import androidx.lifecycle.ViewModel;

public class EditProfileViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
