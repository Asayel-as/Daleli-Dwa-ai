package com.example.dalelidwaai;

import androidx.lifecycle.ViewModel;

public class AddMedicineViewModel extends ViewModel {


    // TODO: Implement the ViewModel
}
